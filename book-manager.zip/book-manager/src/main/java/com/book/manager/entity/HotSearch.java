package com.book.manager.entity;

import lombok.Data;

@Data
public class HotSearch {
    Integer id;
    Integer book_id;
    Integer hotscore;
}
